# Copy Files needed for Quizdown and Carousel

Copy the files in the zip file to (over-write if the file already exists):

1. copy `custom-header.html` to `layouts/partials/custom-header.html`
1. copy `carousel.html` to `layouts/shortcodes/carousel.html`
1. copy `quizdown.html` to `layouts/shortcodes/quizdown.html`
1. copy `colortext.html` to `layouts/shortcodes/colortext.html`
