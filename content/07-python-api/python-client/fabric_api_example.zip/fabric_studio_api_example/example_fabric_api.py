import urllib3

from fabric_studio_client import FabricStudioClient

# Disable insecure request warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Configuration
SERVER_URL = "your-fortipoc-server.example.com"
USERNAME = "admin"
PASSWORD = "your-password"


def main():
    # Create client instance
    client = FabricStudioClient(server=SERVER_URL, username=USERNAME, password=PASSWORD, verify_ssl=False)
    print("Connected to FortiPOC server")

    # List all devices
    print("\nListing all devices...")
    response = client.get('/api/v1/model/device')
    if response.status_code == 200:
        devices = response.json().get('object', [])
        print(f"Found {len(devices)} devices")
        for device in devices:
            print(
                f"- {device.get('name', 'Unnamed')} (ID: {device.get('id', 'Unknown')}) (Fabric ID: {device.get('fabric', 'Unknown')})")
    else:
        print(f"Error: {response.status_code}")

    # Get specific device by ID (example with ID 1)
    device_id = devices[0].get('id', 'Unknown')
    print(f"\nGetting details for device ID {device_id}...")
    response = client.get(f'/api/v1/model/device/{device_id}')
    if response.status_code == 200:
        device = response.json().get('object', {})
        print(f"Device: {device.get('name', 'Unnamed')}")
        print(f"Type: {device.get('vm_type', 'Unknown')}")
    else:
        print(f"Error: {response.status_code}")

    # List all fabrics
    print("\nListing all fabrics...")
    response = client.get('/api/v1/model/fabric')
    if response.status_code == 200:
        fabrics = response.json().get('object', [])
        print(f"Found {len(fabrics)} fabrics")
        for fabric in fabrics:
            print(f"- {fabric.get('name', 'Unnamed')} (ID: {fabric.get('id', 'Unknown')})")
            print(f"  Description: {fabric.get('description', 'No description')}")
            print(f"  Created: {fabric.get('create_date', 'Unknown')}")
    else:
        print(f"Error: {response.status_code}")


if __name__ == "__main__":
    main()
