# File: fortipoc_client/__init__.py
"""
FortiPOC REST Client Package

A Python package for making REST API calls to FortiPOC instances.
"""

from .client import FabricStudioClient

__all__ = ['FabricStudioClient']

