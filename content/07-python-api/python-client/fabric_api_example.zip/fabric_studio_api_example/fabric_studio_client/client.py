#!/usr/bin/env python3
"""
Simple FortiPOC REST Client

A simplified single-file class for making REST API calls to FortiPOC instances.
"""

from typing import Dict, Optional, Union

import requests


class FabricStudioClient:
    """
    A simple client for interacting with FortiPOC REST API.
    
    This client maintains a session with cookies in memory only and provides
    methods for making REST API calls to a FortiPOC instance.
    """

    def __init__(self, server: str, username: str, password: str, verify_ssl: bool = False):
        """
        Initialize a FortiPOC REST client.
        
        Args:
            server: The FortiPOC server URL or IP address
            username: Username for authentication
            password: Password for authentication
            verify_ssl: Whether to verify SSL certificates. Default is False.
        """
        self.server = server.rstrip('/')

        if not self.server.startswith(('http://', 'https://')):
            self.server = f'https://{self.server}'

        self.username = username
        self.password = password
        self.verify_ssl = verify_ssl

        # Create a session to maintain cookies in memory
        self.session = requests.Session()
        self.session.verify = verify_ssl

        # CSRF token will be stored here after login
        self.csrf_token = None

        # Login automatically when the client is instantiated
        self.login()

    def _get_full_url(self, endpoint: str) -> str:
        """
        Build the full URL for an API endpoint.
        
        Args:
            endpoint: API endpoint path
            
        Returns:
            Full URL including server address
        """
        # Remove leading slash if present to avoid double slashes
        if endpoint.startswith('/'):
            endpoint = endpoint[1:]

        return f"{self.server}/{endpoint}"

    def _extract_csrf_token(self) -> Optional[str]:
        """
        Extract the CSRF token from the session cookies.
        
        Returns:
            The CSRF token value or None if not found.
        """
        for cookie in self.session.cookies:
            if cookie.name == 'fortipoc-csrftoken':
                return cookie.value
        return None

    def request(self, method: str, endpoint: str, data: Optional[Union[Dict, str]] = None,
                headers: Optional[Dict[str, str]] = None, json_data: Optional[Dict] = None) -> requests.Response:
        """
        Make a REST API request to the FortiPOC instance.
        
        Args:
            method: HTTP method (GET, POST, PUT, DELETE, etc.)
            endpoint: API endpoint to call (e.g., 'api/v1/session/check')
            data: Form data or raw string data to send
            headers: Additional HTTP headers
            json_data: JSON data to send (will be converted to string)
            
        Returns:
            The response object from the request
            
        Raises:
            Exception: If there's an error with the request
        """
        # Prepare headers
        if headers is None:
            headers = {}

        # Add common headers
        headers['Referer'] = f'{self.server}/'

        # Add CSRF token if available
        if self.csrf_token:
            headers['X-FortiPoC-CSRFToken'] = self.csrf_token

        # Make the request
        url = self._get_full_url(endpoint)

        try:
            response = self.session.request(
                method=method,
                url=url,
                headers=headers,
                data=data,
                json=json_data,
                allow_redirects=True
            )

            # Check for CSRF token in response cookies and update if found
            new_token = self._extract_csrf_token()
            if new_token:
                self.csrf_token = new_token

            return response

        except requests.RequestException as e:
            raise Exception(f"Request failed: {str(e)}")

    def get(self, endpoint: str, headers: Optional[Dict[str, str]] = None) -> requests.Response:
        """Make a GET request to the API."""
        return self.request('GET', endpoint, headers=headers)

    def post(self, endpoint: str, data: Optional[Union[Dict, str]] = None,
             headers: Optional[Dict[str, str]] = None, json_data: Optional[Dict] = None) -> requests.Response:
        """Make a POST request to the API."""
        return self.request('POST', endpoint, data=data, headers=headers, json_data=json_data)

    def put(self, endpoint: str, data: Optional[Union[Dict, str]] = None,
            headers: Optional[Dict[str, str]] = None, json_data: Optional[Dict] = None) -> requests.Response:
        """Make a PUT request to the API."""
        return self.request('PUT', endpoint, data=data, headers=headers, json_data=json_data)

    def delete(self, endpoint: str, headers: Optional[Dict[str, str]] = None) -> requests.Response:
        """Make a DELETE request to the API."""
        return self.request('DELETE', endpoint, headers=headers)

    def login(self) -> Dict:
        """
        Login to the FortiPOC instance.
        
        Returns:
            The JSON response as a dictionary
        """
        # First, get cookies and possibly a CSRF token
        self.get('api/v1/session/check')

        # Now login with credentials
        endpoint = 'api/v1/session/open'
        headers = {'Content-Type': 'application/json'}

        response = self.post(
            endpoint,
            json_data={'username': self.username, 'password': self.password},
            headers=headers
        )

        # Update CSRF token after login
        self.csrf_token = self._extract_csrf_token()

        return response.json()
